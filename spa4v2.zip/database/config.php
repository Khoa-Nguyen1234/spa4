<?php
// config.php
define('DB_HOST', 'localhost');       // Tên máy chủ
define('DB_USER', 'root');           // Tên người dùng MySQL
define('DB_PASSWORD', '');           // Mật khẩu MySQL
define('DB_NAME', 'spa4');  // Tên cơ sở dữ liệu
